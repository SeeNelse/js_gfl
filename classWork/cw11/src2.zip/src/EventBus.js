import Vue from 'vue';
var ev = new Vue();
export default ev;